##changelog

### 1.0.5
* [up]更新三个包文件,支持6.9.x版node
* [add]增加支持js文件inline
* [add]weiget支持type="html"
* [fix]修复linux下路径相关问题

### 1.0.4 
* [add]支持css/js压缩过滤(compressCssReg/compressJsReg)
* [fix]修复define错误处理问题
* [fix]修复css url拼接缺少路径问题
* [change]修改cssImagesUrlReplace默认参数为false

### 1.0.3 
* [fix]修复不能输出null文件
* [add]支持css/js文件输出md5

### 1.0.2 
* [fix]修复细节bug若干
* [add]可以指定将script标签生成到最底部，`<script inbottom>`
* [add]支持本地combo拼接

### 1.0.1 
* [add]cssSprite支持水平合并
* [add]可以指定需要合并的widget名称

### 1.0.0 
* 发布gfe@1.0.0