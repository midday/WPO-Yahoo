var gfe = require('./lib/gfe.js');
var index = module.exports = {
    init:function(argv){
        gfe.init(argv);
    }
};